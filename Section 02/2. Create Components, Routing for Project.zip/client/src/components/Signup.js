import React from "react";

class Signup extends React.Component {
  render() {
    return <div>Signup</div>;
  }
}

export default Signup;
